document.addEventListener("DOMContentLoaded", () => {

	const depositSlider = document.getElementById('up-slider');

	noUiSlider.create(depositSlider, {
		start: 1500000,
		tooltips: true,
		connect: [true, false],
		step: 1000,
		range: {
			'min' : 1000,
			'max' : 3000000
		},
		format: {
			to: function (value) {
				return parseInt(value);
			},
			from: function (value) {
				return parseInt(value);
			}
		},
		pips: {
			mode: 'values',
			values: [1000,3000000],
			density: 500000
		}		
	});

	const rep_depositSlider = document.getElementById('down-slider');

	noUiSlider.create(rep_depositSlider, {
		start: 1500000,
		tooltips: true,
		connect: [true, false],
		step: 1000,
		range: {
			'min' : 1000,
			'max' : 3000000
		},
		format: {
			to: function (value) {
				return parseInt(value);
			},
			from: function (value) {
				return parseInt(value);
			}
		},
		pips: {
			mode: 'values',
			values: [1000,3000000],
			density: 500000
		}
	});

	$( function() {
	$( "#datepicker" ).datepicker();
	});

	$("#datepicker").change(function() {
		console.log($("#datepicker").val());
	});
});

